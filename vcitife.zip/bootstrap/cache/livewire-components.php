<?php return array (
  'alert' => 'App\\Http\\Livewire\\Alert',
  'cart-counter' => 'App\\Http\\Livewire\\CartCounter',
  'home' => 'App\\Http\\Livewire\\Home',
  'products-show' => 'App\\Http\\Livewire\\ProductsShow',
);