<footer class="footer">
  <div class="container">
    All Right Reserved &copy; 2021. V-Citife Team.
  </div>
</footer><?php /**PATH C:\xampp\htdocs\vcitife\resources\views/footer.blade.php ENDPATH**/ ?>