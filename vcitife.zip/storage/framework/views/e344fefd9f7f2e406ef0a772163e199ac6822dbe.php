
<?php $__env->startSection('body'); ?>
    <div class="row">
      <div class="col-md-8">
        <nav aria-label="breadcrumb">
          <ol class="breadcrumb pl-0">
            <li class="breadcrumb-item"><a href="<?php echo e(route('admin.index')); ?>">Admin</a></li>
            <li class="breadcrumb-item"><a href="<?php echo e(route('admin.orders')); ?>">Kelola Pesanan</a></li>
            <li class="breadcrumb-item active" aria-current="page"><?php echo e($order->order_number); ?></li>
          </ol>
        </nav>
      </div>
    </div>
    <h3>Kode Pesanan : <?php echo e($order->order_number); ?></h3>

    <?php
        $i = 1;
    ?>

      <table style="width: 100%" cellpadding="5em">
        <thead>
          <tr>
            <th class="text-center" style="width: 10%">No</th>
            <th style="width: 20%">Detail</th>
            <th style="width: 3%"></th>
            <th></th>
          </tr>
        </thead>

        <tbody>
        <?php $__currentLoopData = $order->details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr class="border-top">
            <td class="text-center align-top" rowspan="12"><?php echo e($i); ?></td>
            <td>Produk</td>
            <td>:</td>
            <td><?php echo e($detail->product->name); ?></td>
          </tr>
          <tr>
            <td>Nama Event</td>
            <td>:</td>
            <td><?php echo e($detail->name); ?></td>
          </tr>
          <tr>
            <td>Logo</td>
            <td>:</td>
            <td><a href="<?php echo e('/storage/' . $detail->logo); ?>" download="logo <?php echo e($detail->name); ?>" class="btn btn-success btn-sm">download logo</a></td>
          </tr>
          <tr>
            <td>Penyelenggara</td>
            <td>:</td>
            <td><?php echo e($detail->organizer); ?></td>
          </tr>
          <tr>
            <td>Tanggal</td>
            <td>:</td>
            <td><?php echo e(date_format(date_create($detail->date), 'd F, Y')); ?></td>
          </tr>
          <tr>
            <td>Waktu</td>
            <td>:</td>
            <td><?php echo e($detail->time ?? '-'); ?></td>
          </tr>
          <tr>
            <td>Lokasi</td>
            <td>:</td>
            <td><?php echo e($detail->location); ?></td>
          </tr>
          <tr>
            <td>Jumlah</td>
            <td>:</td>
            <td><?php echo e($detail->quantity); ?></td>
          </tr>
          <tr>
            <td class="align-top">Nama Peserta</td>
            <td class="align-top">:</td>
            <td><?php echo $detail->participant_manual ? 
            nl2br($detail->participant_manual) : 
            '<a href="/storage/' . $detail->participant_auto . '" download="nama peserta ' . $detail->name . '" class="btn btn-success btn-sm">download file nama peserta</a>'; ?></td>
          </tr>
          <tr>
            <td>Format</td>
            <td>:</td>
            <td><?php echo e($detail->format); ?></td>
          </tr>
          <tr>
            <td>Email Tujuan</td>
            <td>:</td>
            <td><?php echo e($detail->destination); ?></td>
          </tr>
          <tr class="border-bottom">
            <td>Catatan</td>
            <td>:</td>
            <td class="text-danger"><i><?php echo e($detail->notes ?? 'tidak ada catatan'); ?></i></td>
          </tr>

          <?php
              $i++;
          ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </tbody>
      </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Hilmi Almuhtade\dev\vcitife\resources\views/admin/order/detail.blade.php ENDPATH**/ ?>