<div class="form-group">
  <label for="name">Nama Produk</label>
  <input type="text" name="name" value="<?php echo e(old('name') ?? $product->name); ?>" class="form-control mb-2" id="name" autocomplete="off" autofocus>
  <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
      <div class="text-danger">
        <?php echo e($message); ?>

      </div>
  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="row">
  <div class="col-md-6">
    <div class="form-group">
      <label for="price">Harga</label>
      <input type="text" placeholder="ex : 25000" name="price" value="<?php echo e(old('price') ?? $product->price); ?>" class="form-control mb-2" id="price">
      <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <div class="text-danger">
            <?php echo e($message); ?>

          </div>
      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
  </div>

  <div class="col-md-6">
    <div class="form-group">
      <label for="discount">Harga Diskon</label>
      <input type="text" placeholder="ex : 12000" name="discount" value="<?php echo e(old('discount') ?? $product->discount); ?>" class="form-control mb-2" id="discount">
      <?php $__errorArgs = ['discount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <div class="text-danger">
            <?php echo e($message); ?>

          </div>
      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
  </div>
</div>

<div class="form-group">
  <label for="category">Kategori</label>
  <select name="category" class="form-control mb-2" id="category">
    <option disabled selected>Pilih Satu!</option>
    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option <?php echo e($product->category_id == $category->id ? 'selected' : ''); ?> value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </select>
  <?php $__errorArgs = ['category'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
      <div class="text-danger">
        <?php echo e($message); ?>

      </div>
  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="form-group">
  <label for="description">Deskripsi</label>
  <textarea name="description" id="description" class="form-control mb-2" cols="30" rows="6"><?php echo e(old('description') ?? $product->description); ?></textarea>
  <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <div class="text-danger">
      <?php echo e($message); ?>

    </div>
  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="form-group">
  <label for="thumbnail">Foto</label><br>
  <input type="file" name="thumbnail" id="thumbnail">
  <?php $__errorArgs = ['thumbnail'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
      <div class="text-danger">
        <?php echo e($message); ?>

      </div>
  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<button type="submit" class="btn btn-primary mt-3"><?php echo e($submit ?? 'update'); ?></button><?php /**PATH C:\xampp\htdocs\website-vcitife\vcitife\resources\views/products/partials/form-control.blade.php ENDPATH**/ ?>