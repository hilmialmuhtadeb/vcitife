
<?php $__env->startSection('content'); ?>
  <div class="container">

    <div class="row justify-content-center">
      <div class="col-md-8">
  
        <h1 class="mb-3">Ubah Informasi Produk</h1>
        <form method="POST" action="/products/<?php echo e($product->slug); ?>/edit" enctype="multipart/form-data">
          <?php echo method_field('patch'); ?>
          <?php echo csrf_field(); ?>
          <?php echo $__env->make('products.partials.form-control', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </form>
  
      </div>
    </div>

  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\vcitife\resources\views/products/edit.blade.php ENDPATH**/ ?>