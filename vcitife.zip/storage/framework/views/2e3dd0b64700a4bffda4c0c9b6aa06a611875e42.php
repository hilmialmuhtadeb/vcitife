<footer class="footer">
  <div class="container">
    All Right Reserved &copy; 2021. V-Citife Team.
  </div>
</footer><?php /**PATH C:\Users\Hilmi Almuhtade\dev\vcitife\resources\views/footer.blade.php ENDPATH**/ ?>