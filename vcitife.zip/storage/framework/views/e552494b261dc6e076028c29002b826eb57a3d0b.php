
<?php $__env->startSection('body'); ?>

<h2 class="text-center fw-800 mb-4">Hai, Admin!</h2>
    
<div class="row">

  <div class="col-md-4">
    <div class="card bg-vcitife-green shadow-lg">
      <div class="card-number text-vcitife-3"><?php echo e($product); ?></div>
      <div class="card-body">
        <h5 class="card-title text-center text-vcitife-3">Produk</h5>
      </div>
    </div>
  </div>

  <div class="col-md-4">
    <div class="card bg-vcitife-green shadow-lg">
      <div class="card-number text-vcitife-3"><?php echo e($order); ?></div>
      <div class="card-body">
        <h5 class="card-title text-center text-vcitife-3">Penjualan</h5>
      </div>
    </div>
  </div>

  <div class="col-md-4">
    <div class="card bg-vcitife-green shadow-lg">
      <div class="card-number text-vcitife-3"><?php echo e($user); ?></div>
      <div class="card-body">
        <h5 class="card-title text-center text-vcitife-3">Pelanggan</h5>
      </div>
    </div>
  </div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Hilmi Almuhtade\dev\vcitife\resources\views/admin/index.blade.php ENDPATH**/ ?>