
<?php $__env->startSection('body'); ?>
  <div class="row">
    <div class="col-md-12 text-center">
      <h3><span class="fw-800">Pengguna</span> Situs Anda</h3>
    </div>
  </div>

  <table class="table mt-3">
    <thead>
      <tr>
        <th scope="col" style="width: 25%" class="text-center">Peran</th>
        <th scope="col">Nama</th>
        <th scope="col" style="width: 25%" class="text-center">Aksi</th>
      </tr>
    </thead>
    <tbody>

      <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td scope="row" class="text-center">
            <?php if($user->isAdmin == true): ?>
                <div class="text-success">Admin</div>
            <?php else: ?>
                Pelanggan
            <?php endif; ?>
          </td>
          <td class="align-middle"><?php echo e($user->name); ?></td>
          <td class="text-center align-middle">
            <?php if($user->isAdmin == true): ?>
                <div class="btn btn-success btn-sm disabled">sudah menjadi admin</div>
            <?php else: ?>
                <form action="<?php echo e(route('admin.users.addAdmin', $user->id)); ?>" method="POST">
                  <?php echo csrf_field(); ?>
                  <?php echo method_field('patch'); ?>
                  <button type="submit" class="btn btn-secondary btn-sm">jadikan admin</button>
                </form>
            <?php endif; ?>
          </td>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </tbody>
  </table>

  <div class="row justify-content-md-center">
    <?php echo e($users->links()); ?>

  </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\vcitife\resources\views/admin/user.blade.php ENDPATH**/ ?>