
<?php $__env->startSection('content'); ?>
  <div class="container mt-4">
    <div class="row align-items-center">
      <div class="col">
        <?php if(isset($category)): ?>
        <h4 class="text-center">Kategori Produk : <span class="fw-800"><?php echo e($category->name); ?></span></h4>
        <?php else: ?>
        <h2 class="text-center fw-800">Semua Produk</h2>
        <?php endif; ?>
      </div>
    </div>

    <div class="row mt-4">
      <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
      <div class="col-md-3 mb-5">
        <div class="card border-0 shadow">
          <a href="<?php echo e(route('products.show', $product->slug)); ?>">
            <img src="<?php echo e($product->takeImage); ?>" height="200px" class="card-img-top img-fluid">
          </a>
          <div class="card-body">
            <small>
              <a href="<?php echo e(route('categories.show', $product->category->id)); ?>" class="text-danger"><?php echo e($product->category->name); ?></a>
            </small>
            <h6 class="text-secondary card-title"><?php echo e($product->name); ?></h6>
            <h6>Rp <?php echo $product->discount ? '<s>' . number_format($product->price) . '</s>' . '<span class="discount-small ml-2">Rp ' . number_format($product->discount) . '</span>' : number_format($product->price); ?></h6>
            <p class="d-inline">Terjual <?php echo e($product->count); ?></p>
            <div class="my-2 text-secondary">
              <?php if($product->ratingCount > 0): ?>
              <p><i class="fa fa-star orange" aria-hidden="true"></i> <?php echo e($product->rating); ?> (<?php echo e($product->ratingCount); ?> Penilaian)</p>
              <?php else: ?>
                <p>Belum ada penilaian</p>
              <?php endif; ?>
            </div>
          </div>
        </div>
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="col">
          <div class="text-center alert alert-warning mt-3 text-vcitife-1" role="alert">
            Yah, Belum ada produk di toko ini
        </div>
      <?php endif; ?>
    </div>

    <div class="row justify-content-center">
      <?php echo e($products->links()); ?>

    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\vcitife\resources\views/products/index.blade.php ENDPATH**/ ?>