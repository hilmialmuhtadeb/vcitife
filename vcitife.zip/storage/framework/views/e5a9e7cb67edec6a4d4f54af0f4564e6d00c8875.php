<nav class="navbar sticky-top navbar-expand-md navbar-light bg-white shadow-sm">
  <div class="container">
      <a class="navbar-brand" href="<?php echo e(route('home')); ?>">
          <img src="/images/logo1.png" alt="" width="120">
      </a>

      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
          <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">

          <ul class="navbar-nav mr-auto">
              <li class="nav-item">
                  <a href="<?php echo e(route('home')); ?>" class="<?php echo e(request()->is('/') ? 'active ' : ''); ?>nav-link ">Home</a>
              </li>
              <li class="nav-item">
                  <a href="<?php echo e(route('products.index')); ?>" class="<?php echo e(request()->is('products') ? 'active ' : ''); ?>nav-link ">Produk</a>
              </li>
              <li class="nav-item">
                  <a href="<?php echo e(route('guide.index')); ?>" class="<?php echo e(request()->is('guide') ? 'active ' : ''); ?>nav-link ">Panduan</a>
              </li>
              <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('crud')): ?>
              <li class="nav-item">
                  <a href="<?php echo e(route('admin.index')); ?>" class="<?php echo e(request()->is('admin') ? 'active ' : ''); ?>nav-link ">Admin</a>
              </li>
              <?php endif; ?>
          </ul>

          <ul class="navbar-nav ml-auto">
              <!-- Authentication Links -->
              <?php if(auth()->guard()->check()): ?>
              
              <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('carts.index')); ?>">
                    <i class="fa fa-shopping-bag" aria-hidden="true"></i>
                    Keranjang 
                    <?php if(auth()->user()->isCartEmpty): ?>
                        <span class="badge badge-danger badge-pill">
                            <?php echo e(auth()->user()->countCart); ?>

                        </span>
                    <?php endif; ?>
                </a>
              </li>

              <?php endif; ?>
              <?php if(auth()->guard()->guest()): ?>
                  <?php if(Route::has('login')): ?>
                      <li class="nav-item">
                          <a class="nav-link" href="<?php echo e(route('login')); ?>">Masuk</a>
                      </li>
                  <?php endif; ?>

                  <?php if(Route::has('register')): ?>
                      <li class="nav-item">
                          <a class="nav-link" href="<?php echo e(route('register')); ?>">Daftar</a>
                      </li>
                  <?php endif; ?>
              <?php else: ?>
                  <li class="nav-item dropdown">
                      <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                          <?php echo e(Auth::user()->name); ?>

                      </a>

                      <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                          <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                              onclick="event.preventDefault();
                                          document.getElementById('logout-form').submit();">
                              Keluar
                          </a>

                          <a class="dropdown-item" href="<?php echo e(route('carts.history')); ?>">
                              Riwayat Belanja
                          </a>

                          <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                              <?php echo csrf_field(); ?>
                          </form>
                      </div>
                  </li>
              <?php endif; ?>
          </ul>
      </div>
  </div>
</nav><?php /**PATH C:\xampp\htdocs\website-vcitife\vcitife\resources\views/navigation.blade.php ENDPATH**/ ?>