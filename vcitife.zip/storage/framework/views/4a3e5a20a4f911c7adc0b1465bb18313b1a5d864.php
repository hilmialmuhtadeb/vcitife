  <div class="container">
    <div class="row">
      <div class="col-md-8">
        <?php if(session()->has('success')): ?>
          <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
        <?php endif; ?>
      </div>
    </div>

    <div class="row mt-4">

      <div class="col-md-6">
        <img src="<?php echo e($product->takeImage); ?>" class="img-fluid">
      </div>

      <div class="col-md-4">

        <small>
          <a href="#" class="text-danger btn-link">KATEGORI : <?php echo e(strtoupper($product->category->name)); ?></a>
        </small>

        <h1><?php echo e($product->name); ?></h1>
        <p><b>terjual</b> 119 item</p>

        <?php if($product->discount): ?>
        <div class="mb-4 harga">
          Rp <s><?php echo e(number_format($product->price)); ?></s> <span class="discount ml-2">Rp <?php echo e(number_format($product->discount)); ?></span>
        </div>
        <?php else: ?>
        <div class="mb-4 harga">
          <span class="price">Rp <?php echo e(number_format($product->price)); ?></span>
        </div>
        <?php endif; ?>

        <div>
          <h6 class="mb-2">Deskripsi</h6>
          <p><?php echo nl2br($product->description); ?></p>
        </div>

        <?php if(auth()->guard()->check()): ?>
        

        <div>
          <form wire:submit.prevent="addToCart(<?php echo e($product->id); ?>)" method="post">
            <?php echo csrf_field(); ?>
            <input wire:model="quantity.<?php echo e($product->id); ?>" type="hidden">
            <button type="submit" class="btn btn-success">Masukkan keranjang</button>
          </form>
        </div>
        <?php endif; ?>

        

      </div>
    </div>

    
    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Produk : <?php echo e($product->name); ?></h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
            Apakah anda yakin ingin menghapus?
          </div>
          <div class="modal-footer mr-auto">
            <form action="<?php echo e(route('products.delete', $product->slug)); ?>" method="POST">
              <?php echo csrf_field(); ?>
              <?php echo method_field('delete'); ?>
              <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
              <button type="submit" class="btn btn-danger">Hapus</button>
            </form>
          </div>
        </div>
      </div>
    </div>

  </div><?php /**PATH C:\Users\Hilmi Almuhtade\dev\vcitife\resources\views/livewire/products-show.blade.php ENDPATH**/ ?>