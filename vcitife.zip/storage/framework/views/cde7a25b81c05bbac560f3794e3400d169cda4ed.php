
<?php $__env->startSection('content'); ?>

  <div class="container mt-4">
    <h3 class="text-center"><span class="fw-800">Riwayat</span> Pemesanan Anda</h3>

    <?php if($orders->count() == 0): ?>
    <div class="text-center text-danger mt-4">
      Belum ada pesanan sama sekali.
    </div>

    <?php else: ?>
    <table class="table mt-3">
      <thead>
        <tr>
          <th scope="col" class="text-center">Kode Pesanan</th>
          <th scope="col" class="text-center">Tanggal Pemesanan</th>
          <th scope="col">Pemesan</th>
          <th scope="col">Nominal</th>
          <th scope="col" class="text-center">Status Pesanan</th>
        </tr>
      </thead>
      <tbody>

        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td scope="row" class="text-center align-middle"><?php echo e($order->order_number); ?></td>
            <td class="text-center align-middle"><?php echo e(date_format(date_create($order->created_at), 'H.i - d F, Y')); ?></td>
            <td class="align-middle"><?php echo e($order->user->name); ?></td>
            <td class="align-middle">Rp. <?php echo e(number_format($order->summary)); ?></td>
            <td class="text-center align-middle">
              <?php if($order->status == 0): ?>
                <div><button class="btn btn-danger disabled btn-sm">Menunggu pembayaran</button></div>
              <?php elseif($order->status == 1): ?>
                <div><button class="btn btn-warning disabled btn-sm">Sedang diproses</button></div>
              <?php elseif($order->status == 2): ?>
                <div>
                  <a href="<?php echo e(route('ratings.add', $order->id)); ?>" class="btn btn-secondary btn-sm">
                    Beri penilaian
                  </a>
                </div>
              <?php else: ?>
                <div><button class="btn btn-success disabled btn-sm">Selesai</button></div>
              <?php endif; ?>
            </td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      </tbody>
    </table>

    <?php echo e($orders->links()); ?>

    <?php endif; ?>
  </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\website-vcitife\vcitife\resources\views/carts/history/index.blade.php ENDPATH**/ ?>