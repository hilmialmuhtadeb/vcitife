
<?php $__env->startSection('content'); ?>
<div class="container">

  <div class="row justify-content-center">
    <div class="col-md-8">

      <h1 class="mb-3">Produk Baru</h1>
      <form method="POST" action="<?php echo e(route('products.store')); ?>" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo $__env->make('products.partials.form-control', ['submit' => 'tambahkan'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      </form>

    </div>
  </div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Hilmi Almuhtade\dev\vcitife\resources\views/products/new.blade.php ENDPATH**/ ?>