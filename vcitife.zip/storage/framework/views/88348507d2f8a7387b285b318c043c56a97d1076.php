<li class="nav-item">
    <a class="nav-link" href="<?php echo e(route('carts.index')); ?>">
        Keranjang <i class="fa fa-shopping-bag" aria-hidden="true"></i>
        <span class="badge badge-danger">
            <?php echo e($cart_count); ?>

        </span>
    </a>
</li>
<?php /**PATH C:\Users\Hilmi Almuhtade\dev\vcitife\resources\views/livewire/cart-counter.blade.php ENDPATH**/ ?>