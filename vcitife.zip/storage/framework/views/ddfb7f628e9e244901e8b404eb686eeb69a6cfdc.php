
<?php $__env->startSection('body'); ?>
  <div class="row">
    <div class="col">
      <h3 class="text-center">List Pesanan : <span class="fw-800">Perlu Dikirim</span></h3>
    </div>
  </div>

  <?php if($orders->count() == 0): ?>
  <div class="text-danger text-center mt-4">
    Belum ada pesanan yang perlu dikirim.
  </div>
  <?php else: ?>
  <table class="table mt-3">
    <thead>
      <tr>
        <th scope="col" class="text-center">Kode Pesanan</th>
        <th scope="col" class="text-center">Nomor Unik</th>
        <th scope="col">Pemesan</th>
        <th scope="col">Nominal</th>
        <th scope="col" class="text-center">Aksi</th>
      </tr>
    </thead>
    <tbody>

      <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td scope="row" class="text-center align-middle"><?php echo e($order->order_number); ?></td>
          <td class="text-center align-middle"><?php echo e($order->unique_number); ?></td>
          <td class="align-middle"><?php echo e($order->user->name); ?></td>
          <td class="align-middle">Rp. <?php echo e(number_format($order->summary)); ?></td>

          <td class="text-center align-middle">
            <form action="<?php echo e(route('admin.orders.update', $order->id)); ?>" method="post">
              <?php echo csrf_field(); ?>
              <?php echo method_field('patch'); ?>
              <button type="submit" class="btn btn-success btn-sm"><i class="fa fa-check" aria-hidden="true"></i> <p class="d-inline">selesai</p></button>
              <a href="<?php echo e(route('admin.orders.detail', $order->id)); ?>" class="btn btn-primary btn-sm"><i class="fa fa-info-circle" aria-hidden="true"></i> <p class="d-inline">info</p></a>
            </form>
          </td>

        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </tbody>
  </table>

  <div class="row justify-content-md-center">
    <?php echo e($orders->links()); ?>

  </div>

  <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Hilmi Almuhtade\dev\vcitife\resources\views/admin/order/wait.blade.php ENDPATH**/ ?>