
<?php $__env->startSection('content'); ?>
<div class="container">
  <div class="row">
    <div class="col-md-12">
      <nav aria-label="breadcrumb">
        <ol class="breadcrumb pl-0">
          <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
          <li class="breadcrumb-item"><a href="<?php echo e(route('products.index')); ?>">Produk</a></li>
          <li class="breadcrumb-item active" aria-current="page"><?php echo e($product->name); ?></li>
        </ol>
      </nav>
    </div>
  </div>

  <div class="row">
    <div class="col-md-6">
      <img src="<?php echo e($product->takeImage); ?>" class="img-fluid">
    </div>

    <div class="col-md-4">

      <small> 
        <a href="<?php echo e(route('categories.show', $product->category_id)); ?>" class="text-vcitife-4 btn-link">KATEGORI : <?php echo e(strtoupper($product->category->name)); ?></a>
      </small>

      <h1><?php echo e($product->name); ?></h1>
      <p><b>terjual</b> <?php echo e($product->count); ?> item</p>

      <?php if($product->discount): ?>
      <div class="harga">
        Rp <s><?php echo e(number_format($product->price)); ?></s> <span class="discount ml-2">Rp <?php echo e(number_format($product->discount)); ?></span>
      </div>
      <?php else: ?>
      <div class="harga">
        <span class="price">Rp <?php echo e(number_format($product->price)); ?></span>
      </div>
      <?php endif; ?>
      
      <div class="my-2 text-secondary">
        <?php if($product->ratingCount > 0): ?>
          <i class="fa fa-star orange" aria-hidden="true"></i> <?php echo e($product->rating); ?> (<?php echo e($product->ratingCount); ?> Penilaian)
        <?php else: ?>
          <p>Belum ada penilaian</p>
        <?php endif; ?>
      </div>

      <div>
        <h6 class="mb-2">Deskripsi</h6>
        <p><?php echo nl2br($product->description); ?></p>
      </div>

      <div>
        <form action="<?php echo e(route('carts.store')); ?>" method="post">
          <?php echo csrf_field(); ?>
          <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">
          <button type="submit" class="btn btn-vcitife bg-vcitife-middle rounded-pill btn-block">Masukkan keranjang</button>
        </form>
      </div>

    </div>
  </div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\website-vcitife\vcitife\resources\views/products/show.blade.php ENDPATH**/ ?>