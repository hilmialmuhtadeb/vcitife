<div class="text-center">
    <button wire:click=<?php echo e(increment()); ?>>+</button>
    <h1><?php echo e($count); ?></h1>
</div>
<?php /**PATH C:\Users\Hilmi Almuhtade\dev\vcitife\resources\views/livewire/counter.blade.php ENDPATH**/ ?>