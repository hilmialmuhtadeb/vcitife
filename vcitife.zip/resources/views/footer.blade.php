<footer class="footer">
  <div class="container">
    All Right Reserved &copy; 2021. V-Citife Team.
  </div>
</footer>